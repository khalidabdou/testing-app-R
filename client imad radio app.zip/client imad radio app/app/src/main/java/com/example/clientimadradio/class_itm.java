package com.example.clientimadradio;

public class class_itm {

    int ids;
    String img;
    String name_station;
    String desc;
    String url;
    int favorite;

    class_itm(int ids, String img, String name_station, String desc, String url, int favorite) {
        this.ids = ids;
        this.img = img;
        this.name_station = name_station;
        this.desc = desc;
        this.url = url;
        this.favorite = favorite;
    }
}
